# Figure 4 and Supplementary Figure 10: data and sources

These data and source files accompany the **KnottedGraph** arXiv
preprint `2609.31152v1.pdf`. Figure 4 is on PDF page 6 (printed page 6);
Supplementary Figure 10 is on PDF page 36 (printed page 26). The figure
artwork is available in the repository's figure gallery; manuscript source
is included in `source/manuscript_main.tex`.

## Data sources and recorded status

The notebook in `source/05_yamada_formula_discovery.ipynb` defines the
`05a_*`, `05b_*`, and `05c_*` output schemas and writes them under
`User_guide/applications/results/05_yamada_formula_discovery/`.
The supplied checkouts contained no saved ledgers at that location.
`audit/reproducibility_inventory.json` records 12 expected artifacts with
`null` paths and zero retained notebook execution outputs.

The JSON files in `audit/` contain **retrospective exact checks** with dates
and source identities in `provenance.json`. Original `05a/05b/05c` ledgers
and independently timestamped historical formula-freezing records remain
unavailable in the supplied material. The CSVs in `data/` are compact
exports of the audit JSONs, made by `REGENERATE_EXTRACTS.py`.

## File map

| Paper item | Artwork and directly relevant data | What it supports |
|---|---|---|
| Fig. 4a | `source/05_yamada_formula_discovery.ipynb`; `audit/reproducibility_inventory.json` | Discovery/test protocol and expected output schemas; source-record availability is listed above. |
| Fig. 4b-d, e-g, h-j | `data/figure4_homogeneous_m1_m2.csv`; `audit/mixed_family/records.json` | Direct retrospective exact results for the three `m=1,2` examples. The general-`m` expressions are in the manuscript source and notebook. |
| Fig. 4k | `data/figure4_mixed_family_459.csv`; `audit/mixed_family/records.json`, `word_plan.json`, `certificate.json`, `provenance.json` | All 459 completed retrospective mixed-word coefficient comparisons. In this dataset `L` means cross-linked, `D` lower-paired, and `B` two-sided. |
| Fig. 4l | `data/figure4_pure_braid_324.csv`; `data/figure4_order_sensitive_AAB_ABA_BAA.csv`; `audit/discovery/` | Direct raw and normalized Laurent coefficients for 324 short pure-braid words, the 15-word Hankel basis, exact transfer matrices, verification certificate, and provenance. Here `A,B` are braid blocks, unrelated to the mixed-family `B` above. |
| Supplementary Fig. 10 | `data/suppfig10_AAABA.json`; `audit/discovery/` | The exact `AAABA=A^3BA` direct record on the 8-vertex, 12-edge graph. Validation role: **in-sample Hankel construction**, through `H[AA,ABA]`; the word is outside the 15 coordinate basis words. |
| Additional pure-braid checks | `audit/discovery_long_words/` | Two completed retrospective exact length-101 comparisons from the 20-word plan. Completed records cover two cases; the remaining 18 have no completed result in this audit. |

For the computation protocols, recorded checks and reproduction commands, see
`source/discovery_and_protocols.md`. The audit scripts in `source/` read the
original notebook and generate the audit JSONs; they require the full
KnottedGraph repository and its environment. `REGENERATE_EXTRACTS.py` only
converts the included JSON records to the included compact tables.
`source/manuscript_main.tex` is the submission source for the figure captions
and surrounding text.

## Using the included notebook

`source/05_yamada_formula_discovery.ipynb` is the **actual source notebook**
for the three `05a`, `05b`, and `05c` workflows. It defines the constructors,
candidate formulas, planned cases, output names, and routines that generate
fresh exact results. The audit scripts in `source/` use cells from that
notebook to make the retrospective JSONs here.

Run the notebook from a full KnottedGraph checkout with its installed
environment. It generates fresh `05a/05b/05c` outputs using the notebook's
schemas and paths. The included `audit/` JSONs and `data/` CSVs are separate
exports for inspecting the recorded retrospective checks.

## Browse the records

Start with the CSVs in `data/`, then inspect the corresponding `audit/` JSONs,
`provenance.json` and `certificate.json` to follow the exact checks and their
source identities. The file map identifies each record's validation role.

`SHA256SUMS.txt` records hashes for the files in this archive.
