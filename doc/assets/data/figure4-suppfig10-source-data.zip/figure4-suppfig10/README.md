# Figure 4 and Supplementary Figure 10: student handoff

This data-and-source handoff was checked against the **KnottedGraph** arXiv
preprint `2609.31152v1.pdf`. Figure 4 is on PDF page 6 (printed page 6);
Supplementary Figure 10 is on PDF page 36 (printed page 26). The figure
artwork and paper PDF are intentionally excluded from this folder.

## Important answer about the requested `05a/05b/05c` results

The original files named `05a_*`, `05b_*`, and `05c_*` are **not in the
available repository**. The notebook in `source/05_yamada_formula_discovery.ipynb`
is configured to write them to
`User_guide/applications/results/05_yamada_formula_discovery/`, but that
directory and its saved ledgers were absent in the inspected checkouts. The
read-only `audit/reproducibility_inventory.json` lists 12 expected artifacts,
all with `null` paths, and finds zero retained notebook execution outputs.
We cannot infer that the original files were never generated somewhere else.

The JSON files in `audit/` are **new retrospective exact checks**, dated in
their `provenance.json` files. They are useful source data for the figures,
but they are not the original `05a/05b/05c` data, independent timestamped
formula freezes, or evidence of the historical blind split. The CSVs in
`data/` are compact exports of those JSONs, made by `REGENERATE_EXTRACTS.py`.
Please label them "retrospective audit data" if placed on the website.

## File map

| Paper item | Artwork and directly relevant data | What it supports |
|---|---|---|
| Fig. 4a | `source/05_yamada_formula_discovery.ipynb`; `audit/reproducibility_inventory.json` | The notebook describes the discovery/test protocol. No original D/T ledgers or historical freeze record were found. |
| Fig. 4b-d, e-g, h-j | `data/figure4_homogeneous_m1_m2.csv`; `audit/mixed_family/records.json` | Direct retrospective exact results for the three `m=1,2` examples. The general-`m` expressions are in the manuscript source and notebook; the original `05a` ledger is missing. |
| Fig. 4k | `data/figure4_mixed_family_459.csv`; `audit/mixed_family/records.json`, `word_plan.json`, `certificate.json`, `provenance.json` | All 459 completed retrospective mixed-word coefficient comparisons. In this dataset `L` means cross-linked, `D` lower-paired, and `B` two-sided. The original `05b` ledger is missing. |
| Fig. 4l | `data/figure4_pure_braid_324.csv`; `data/figure4_order_sensitive_AAB_ABA_BAA.csv`; `audit/discovery/` | Direct raw and normalized Laurent coefficients for 324 short pure-braid words, the 15-word Hankel basis, exact transfer matrices, verification certificate, and provenance. Here `A,B` are braid blocks, unrelated to the mixed-family `B` above. The original `05c` ledger is missing. |
| Supplementary Fig. 10 | `data/suppfig10_AAABA.json`; `audit/discovery/` | The exact `AAABA=A^3BA` direct record on the 8-vertex, 12-edge graph. It occurs as `H[AA,ABA]` in the Hankel input and is **not an independent holdout**, despite being outside the 15 coordinate basis words. |
| Additional pure-braid checks | `audit/discovery_long_words/` | Two new exact length-101 comparisons and the larger planned list. They are supplementary retrospective checks; the other planned long-word cases were not completed in that audit. |

For detailed scientific limitations and reproduction commands, see
`source/discovery_and_protocols.md`. The audit scripts in `source/` read the
original notebook and generate the audit JSONs; they require the full
KnottedGraph repository and its environment. `REGENERATE_EXTRACTS.py` only
converts the included JSON records to the included compact tables.
`source/manuscript_main.tex` is the submission source for the figure captions
and surrounding text.

## Using the included notebook

`source/05_yamada_formula_discovery.ipynb` is the **actual source notebook**
for the three `05a`, `05b`, and `05c` workflows. It defines the constructors,
candidate formulas, planned cases, output names, and routines that generate
fresh exact results. The audit scripts in `source/` use cells from that
notebook to make the retrospective JSONs here.

The notebook does **not** read the included `audit/` JSONs or `data/` CSVs as
drop-in replacements for its own `05a/05b/05c` files. It expects its own
schemas and paths. To execute it, use the full KnottedGraph repository with
the correct package/environment; the notebook file in this ZIP alone is not
a runnable standalone package. Running it now could generate new outputs,
but it would not recover the original historical run or prove that a candidate
was frozen before its purported holdout.

## Website guidance

Link the CSVs in `data/` for easy browsing, and the corresponding `audit/` JSONs plus
`provenance.json` and `certificate.json` for reproducibility. Keep the note
above about the missing original `05a/05b/05c` ledgers visible alongside the
data. In particular, do not describe `AAABA` as held out.

`SHA256SUMS.txt` records hashes for the files in this handoff folder.
