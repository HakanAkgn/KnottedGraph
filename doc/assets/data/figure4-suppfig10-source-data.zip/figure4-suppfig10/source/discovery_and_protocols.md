# Reproduction protocols and recorded checks

The recorded exact checks were completed on 18 September 2026. Their provenance files identify the inputs, source snapshots and execution environments.

## Exact transfer reconstruction

The supplied `audit_discovery_artifacts.py` reads the pure-braid constructors and raw invariant evaluator from cells 68, 69, 71 and 72 of `User_guide/applications/05_yamada_formula_discovery.ipynb`. The script checks that the imported Python package belongs to the requested checkout. Its provenance records the Git commit, dirty-source status, notebook and selected-cell hashes, source hashes, Python and package versions, and native-backend availability.

Run from the repository with its installed uv environment:

```sh
uv run python dev/audit_discovery_artifacts.py \
  --repo . \
  --out User_guide/applications/results/arxiv_revision/discovery \
  --symbolic
```

Use a fresh output directory to preserve an earlier audit. The data and algebra are deterministic; timestamps and execution timings are not. The script currently addresses notebook cells by index and saves their hashes, so a reorganized notebook requires a reviewed update to the cell indices.

The completed audit recomputed 324 distinct short-word spatial graphs and their raw integer Laurent coefficients:

- 255 words in the union of `u+v`, `u+A+v`, `u+B+v`, where `u,v` range over the manuscript's 15-word Hankel basis. Their maximum length is nine.
- All 255 binary words of lengths zero through seven. These are a different set of 255 words; 69 are additional to the Hankel set.

Exact arithmetic verifies:

1. `det(H(2)) != 0`, hence rank 15 over the rational-function field. The exact rational determinant is retained in `certificate.json`.
2. `H H_inverse = I`, `H T_A = H_A`, `H T_B = H_B`.
3. Both operator identities `(T-Y^2 I)(T-Y^-2 I)(T-Y^-4 I)=0`.
4. `T_A T_B != T_B T_A`, with a nonzero exact entry of the commutator recorded.
5. `L_transpose T_w R` equals direct raw evaluation for all 324 audited words.
6. For all binary words through length seven, raw polynomials agree under reversal; within a fixed A/B count class, no additional equalities between distinct words occur.

The machine-readable outputs are:

| File | Contents |
|---|---|
| `short_exact_records.json` | Direct graph/PD evaluations, integer coefficient dictionaries, hashes, timings |
| `word_plans.json` | 15-word basis, all short-word lists, exact 20-word long-test plan |
| `hankel_input_matrices.json` | Exact H, H_A and H_B entries |
| `exact_transfer_matrices.json` | H, H_A, H_B, H inverse, T_A, T_B, L transpose and R over Q(Y) |
| `certificate.json` | Verification results and nonzero rank/commutator witnesses |
| `exhaustive_short_word_checks.json` | Reversal/collision checks for all words through length seven |
| `provenance.json` | Actual environment and source identity for the new run |
| `new_audit_freeze.json` | Timestamped snapshot of this audit's formula and planned long words only |

The formula payload's canonical SHA256 (excluding its hash field) is
`72ac75fe0ca14632e888207d7c39ec71b05dac0c7e5a44eafb37a27c246e63a3`.
The 255-word and expanded 324-word runs independently produced this same matrix artifact.

### Scope of the exact checks

The exact finite-data checks establish the stated finite-block rank, matrix identities and agreement on the listed words. Extending the result to every graph closure requires a family-specific map to the proposed 15-state representation and a proof of its closure/action correspondence. An all-word identity, upper bound and minimality require that derivation; the 15-dimensional skein algebra supplies the ambient algebra.

A subsequent bounded audit completed **two full exact length-101 comparisons**: `A^51 B^50` and `(AB)^50 A`. In each case the directly evaluated raw Laurent coefficient dictionary equals the transfer prediction. The complete 20-word plan and the two successful records are retained in `User_guide/applications/results/arxiv_revision/discovery_long_words/`; completed results cover two of the 20 cases in the 240-second run, with the other 18 recorded as unfinished. These are retrospective extrapolation checks against the existing candidate.

To repeat the bounded check into a fresh output directory:

```sh
uv run python dev/audit_discovery_long_words.py --repo . \
  --artifact User_guide/applications/results/arxiv_revision/discovery \
  --out /tmp/new_discovery_long_words --seconds 240
```

The certificate records completed and unfinished cases for the stated hardware and time budget.

For the homogeneous and commuting mixed formulas, use the normalized formulas only for nonempty constructions (m >= 1). At m=0, the common matrix contraction is `-Y^2(1+Y+2Y^2+Y^3+Y^4)`, whose minimum degree is two. Its normalized expression is `-(1+Y+2Y^2+Y^3+Y^4)`. The zero-polynomial normalization convention must also be explicit.

## Historical records and word-plan discrepancy

The discovery notebook has no retained execution outputs. None of its expected 05a, 05b or 05c coefficient/verification ledgers were found in the checkout's application results. The full notebook does contain executable candidate expressions, a prospective order of operations, and deterministic plans. Use these artifacts to rerun the stated procedure; establishing historical candidate timing and model inputs requires independently dated source material.

Original prompts, model conversation transcripts and independently timestamped historical candidate snapshots remain unavailable in the supplied project material. `prediction_frozen_before_holdout` records the order of operations in a notebook execution; historical discovery and withholding chronology requires the corresponding independently dated records.

There is a historical plan/count discrepancy: notebook cell 60 generates **459** mixed-theta words, comprising 363 exhaustive nonempty words of lengths one through five and 96 additional words of lengths six and seven, rather than the original manuscript's 500. A historical 500-row ledger is unavailable in the supplied material. The retrospective audit completed **all 459 exact normalized polynomial comparisons successfully** after the constructor/contact/projection preflights. Word lists, per-word coefficient results and the certificate are retained in `User_guide/applications/results/arxiv_revision/mixed_family/`. The separate mixed-family long-word plan remains unfinished.

```sh
uv run python dev/audit_mixed_family.py --repo . --out /tmp/new_mixed_family_audit
```

Available exact outputs:

The archive includes family constructors, executable candidate expressions, deterministic word lists, raw coefficients for 324 distinct short pure-braid words and two length-101 words, all 459 mixed-family comparisons, exact Hankel and transfer matrices, and exact-arithmetic verification scripts. The provenance files record these retrospective computations; the historical-record inventory is described above.

The certificates and inventory distinguish completed finite checks, unfinished test plans and historical source-record availability.

## Hamiltonian sampling recovered from code and retained HTML

`audit_reproducibility_inventory.py` reads the source snapshots and exports notebook controls, exact rational sample arrays and retained HTML metadata.

The historical notebook controls recovered before revision were:

- Lambda: 60 inclusive samples, `lambda_j=j/59`, j=0,...,59. Thus delta lambda is 1/59, approximately 0.0169491525424.
- Candidate Gamma/energy: 50 inclusive samples, `Gamma_k=0.30+(99/980)k`, k=0,...,49, ending at 5.25. Step approximately 0.101020408163.
- Spatial grid: 120 cubed.
- `N_JOBS=2` was declared, but the actual row/cache scan loop is sequential; it does not dispatch two workers. OMP/MKL/OpenBLAS/NumExpr thread counts use `setdefault`, so preexisting overrides remain possible. This differs from the new pilot, which explicitly launches two processes.
- Smoothing retries: 4.0, 1.0, 0.25, 0.0.
- Projection retry samples: 32, 96, 256.

The retained HTML `NewPhaseMapPlots/RealMaterials/html/07_hamiltonian_yamada_plotly_region_geometry_with_materials.html` includes all five analytic transitions. Their retained Gamma ranges are prefixes of the common candidate array:

| Transition | Gamma samples | Exact last candidate index | Last Gamma |
|---|---:|---:|---:|
| Hopf to trefoil | 16 | 15 | 1.8153061224489797 |
| Hopf to Solomon | 24 | 23 | 2.623469387755102 |
| Unknot to trefoil | 16 | 15 | 1.8153061224489797 |
| Unknot to Solomon | 24 | 23 | 2.623469387755102 |
| Trefoil to cinquefoil | 39 | 38 | 4.138775510204082 |

This gives 7,140 retained parameter samples. The historical notebook stopped/cropped at the first row classified as a one-vertex result at every lambda. Physical transition values require a model-specific analysis beyond this sampled terminal-row rule. The HTML rounds its displayed floats to six decimal places; exact candidate values follow the notebook formulas above.

### Interpret the sampled Hamiltonian geometry

The model source uses m=2. Most knot/link endpoints use c0=0.5, but the Solomon endpoint uses **c0=0.333**, not exactly 1/3. The interpolation to Solomon therefore changes the endpoint coordinate-map parameter as well as p,q. Use the endpoint-specific c0 values when defining the interpolation.

The numerical model includes `i Gamma sigma_y`; its interior mask is `spectrum.real == 0`, the exceptional-volume region. For real d1,d3 and positive Gamma this is geometrically `d1^2+d3^2 <= Gamma^2`, the same sublevel set as the Hermitian two-band positive-energy region E <= Gamma. A Hermitian Fermi-volume interpretation follows from this equality of geometric sublevel sets; the computed Hamiltonian itself is non-Hermitian.

The default sampled domain is [-pi,pi] x [-pi,pi] x [0,pi], with displayed coordinate scale (1,1,2). The audit found no periodic face-identification operation in this route. Interpret these records in the stated finite sampled box; periodic face identification defines a different boundary topology.

The historical Hamiltonian notebook also performed substantial phase-label postprocessing: four-connected parameter components smaller than `max(5,ceil(0.01*number_of_displayed_grid_cells))` are iteratively assigned a neighboring large component's label. Votes use the eight neighboring pixels, with total label area and then label index as tie breakers. The cell-area threshold controls display-label reassignment. Compare the raw and reassigned maps with the retained reassigned-cell mask when assessing small regions.

Retained HTML metadata:

| Transition | Raw classes | Filtered classic classes/regions | Contraction-grouped classes/regions |
|---|---:|---:|---:|
| Hopf to trefoil | 9 | 4 / 4 | 4 / 4 |
| Hopf to Solomon | 28 | 7 / 8 | 4 / 4 |
| Unknot to trefoil | 8 | 5 / 6 | 4 / 5 |
| Unknot to Solomon | 40 | 5 / 5 | 5 / 5 |
| Trefoil to cinquefoil | 19 | 6 / 8 | 5 / 7 |

These counts describe the legacy display metadata, which combines spatial and abstract graph results. Complete raw per-cell arrays are unavailable for reconstructing a validated Yamada map. The pilot below records volume homology and graph extraction on a separate sampling plan.

## Hamiltonian homology pilot and recorded controls

The finite-window pilot measures volume homology and graph extraction on its own sampling plan; the historical map contains 7,140 cells. It evaluates 1,309 distinct points: 11 interpolation values `lambda_j=j/10` and the same energy-prefix lengths 16,24,16,24,39 listed above, with `E_k=0.30+(99/980)k`. Resolution is 64 cubed, with two explicit worker processes. The records use raw parameter-space labels in a finite sampled box. Continuum convergence and embedding classification require their own checks.

The raw sampled volume uses 26-connected foreground and 6-connected complement. Its first Betti number is `b1=b0+b2-chi`. Empty masks, positive-b2 masks and boundary-touching masks are unsupported for the present closed-graph interpretation. Other masks are checked for agreement of the voxel skeleton's and extracted graph's b0/b1 through cleanup, pruning, simplification and accepted smoothing. Homology agreement is a necessary consistency check; deformation retraction and ambient isotopy require geometric justification.

Final outcomes:

| Transition | Betti-consistent extraction | Unsupported boundary |
|---|---:|---:|
| Hopf to trefoil | 83 | 93 |
| Hopf to Solomon | 84 | 180 |
| Unknot to trefoil | 34 | 142 |
| Unknot to Solomon | 43 | 221 |
| Trefoil to cinquefoil | 1 | 428 |
| Total | **245** | **1,064** |

All 1,309 masks have b2=0. Across the finite-window masks, max b0=9 and max b1=7. The first pass took 386.51 seconds on the audit machine. Seven first-pass extraction errors were traced to cleanup deleting already existing isolated components. After preserving those components, the seven affected cells were reevaluated in 2.22 seconds and passed. `first_pass_records.json`, `first_pass_summary.json` and `isolated_component_rerun.json` preserve this history separately from final `records.json` and `summary.json`. The first-pass source snapshot and final corrected notebook hashes are both retained.

The notebook06 snapshot used for the pilot disables legacy classification reports, display filtering and abstract-contraction diagnostics. Spatial evaluation failures remain unavailable; high-valence diagram results carry their scope/projection metadata. Empty, failed and topologically inconsistent extractions retain their explicit status. A missing validated terminal row retains the full requested energy range. Notebook06 and its normalizer preserve these controls.

The recorded function regression audit passes **12 checks**, including isolated-component preservation; the recorded notebook-hygiene suite passes **11 tests**. The helper loads the relevant notebook functions for these focused checks.

Regenerate the final raw pilot and figure from the corrected notebook:

```sh
uv run python dev/run_hamiltonian_homology_pilot.py --repo . \
  --notebook User_guide/applications/06_hamiltonian_yamada_phase_maps.ipynb \
  --out /tmp/new_hamiltonian_homology --seconds 600
uv run python dev/plot_hamiltonian_homology_pilot.py \
  --data /tmp/new_hamiltonian_homology --out /tmp/new_hamiltonian_homology/figure
uv run python dev/audit_hamiltonian_notebook.py \
  --notebook User_guide/applications/06_hamiltonian_yamada_phase_maps.ipynb \
  --out /tmp/new_hamiltonian_function_checks
```

A fresh run uses the corrected cleanup for all points. Figure generation also works directly from the archived final `records.json` and `plan.json`, without rerunning geometry. `figure_arrays.npz` retains each plotted b0, b1, b2 and status array; `figure_metadata.json` records the raw-source hash and absence of filtering. The figure displays finite-window homology even at boundary-touching points and keeps unsupported extraction status separate. The archived PDF's SHA256 is `2dc4e2ca39a67492c6ce8d7d176516f25ca127f591f876a552948ddeb6144db1`.

## Recorded benchmark protocol and environment

The recorded benchmark notebook and `dev/benchmark_topoly_paper_scaling.py` establish:

- Exactly one timed invariant evaluation for each requested graph/framework pair, in a fresh spawned worker; no explicit warmup or repeated timing distribution.
- Worker `perf_counter` starts just before framework evaluation and stops after conversion to the comparison coefficient dictionary.
- Geometric construction/projection, parent/worker startup and result serialization are outside that worker timing. Separate wall/projection columns exist.
- KnottedGraph: raw invariant, `normalize=False`, `n_jobs=1`, `method="negami"`.
- Topoly: its process-global Yamada memo table is cleared inside the timed function; `point(max_cross=5000)` is used.
- Recorded notebook limits: KnottedGraph 600 seconds, Topoly 100,000 seconds.
- Projection preprocessing may be reused from a geometry/PD cache. Notebook code recomputes KnottedGraph invariant calls, reuses Topoly results from the ledger, and skips later Topoly family cases after a non-pass.
- The retained comparison ledger has 112 rows. Its columns do not record the historical CPU model, RAM, OS, dependency versions, compiler flags, measured thread-environment values or per-row source commit.

The audit machine's arm64/macOS environment identifies this audit run. Historical benchmark hardware remains unavailable in the comparison ledger. Record any additional run in a separate dated ledger with its own execution environment.

## Associated source and data paths

The audit notes record the following repository destinations:

| Source file or directory | Recorded repository destination |
|---|---|
| `audit_discovery_artifacts.py` | `dev/audit_discovery_artifacts.py` |
| `audit_reproducibility_inventory.py` | `dev/audit_reproducibility_inventory.py` |
| `audit_mixed_family.py`, `audit_discovery_long_words.py` | `dev/` |
| `audit_hamiltonian_notebook.py`, `run_hamiltonian_homology_pilot.py`, `plot_hamiltonian_homology_pilot.py` | `dev/` |
| `mixed_family_audit/` | `User_guide/applications/results/arxiv_revision/mixed_family/` |
| `discovery_long_word_audit/` | `User_guide/applications/results/arxiv_revision/discovery_long_words/` |
| `hamiltonian_homology_pilot/` | `User_guide/applications/results/arxiv_revision/hamiltonian_homology/` |
| `hamiltonian_integrity_final_audit/` | `User_guide/applications/results/arxiv_revision/hamiltonian_integrity/` |
| `discovery_audit/` | `User_guide/applications/results/arxiv_revision/discovery/` |
| `reproducibility_inventory/` | `User_guide/applications/results/arxiv_revision/inventory/` |
| this document | `doc/reproducibility/discovery_and_protocols.md` |

Provenance records the commit, working-tree modifications and source hashes for each retrospective audit run.
